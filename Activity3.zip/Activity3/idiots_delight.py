import cards
deck = cards.deck_card_list
def deal_hand():
    hand_=[]    
    for i in range(4):
        hand_.append(deck.pop())
    #hand = hand[3]  
    return hand_, deck
   
def discard(hand, num):  
    if num != 4 and num != 2:
        hand_ = hand_[3] 
        return hand_
       
    if len(hand) < 4:

        return hand_
       
    if num == 4:
        for i in range(4):
            hand_.pop()
           
    if num == 2:
        hand_.pop(-2)
        hand_.pop(-2)
    
    #hand = hand[3]
    return hand_

def play_round():
    hand_=[]
    num = len(hand_)
    for i in range(4):
        hand_.append(deck.pop)
    if num<4:
        dif=4-num
        for i in range(dif):
            hand_.append(deck.pop)
    if len(deck)!=0:
        hand_.append(deck.pop)

    while num>=4:
        discard(hand_,num)

    for i in range(4):
        if hand_[i][0] == hand_[-1][0]:
            discard(hand_,num)

    if hand_[2][1] == hand_[3][1]:
        hand_.remove(hand_[2])
        hand_.remove(hand_[3])
    #hand = hand[3] 
    return hand_,deck

def main():
    deal_hand()
    u,v = play_round()
    print(u)
    while len(u)<4:
        play_round()
    
main()
