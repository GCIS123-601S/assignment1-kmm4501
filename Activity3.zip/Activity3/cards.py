import random
deck_card_list=[]
def make_card(rank, suit):
    reset_flag="\033[37m"
    red_flag="\033[31m"
    Black_flag="\033[34m"

    pref="/033["
    reset= f"{pref}0m"
    red="31m"
    black="30m"

    print(reset_flag)
    rank_str = ""
    rank_short = ""
    rank_list = ["Jack","Queen","King","Ace"]
    u = 0
    """
    for i in rank_list:
        for j in range(11,14):
            if rank == j: #If rank = 11
                rank_str=i #rank_str = rank_list[0] = "Jack"
                rank_short=i[0] #"Jack[0]" = J"
            else:
                rank_str = str(rank)
                rank_short = str(rank)
            u+=1
    """

    
    for items in rank_list:
        if rank == 11:
            rank_str=rank_list[0]
            rank_short=rank_str[0]
        elif rank == 12:
            rank_str=rank_list[1]
            rank_short=rank_str[0]
        elif rank == 13:
            rank_str=rank_list[2]
            rank_short=rank_str[0]
        elif rank == 14:
            rank_str=rank_list[3]
            rank_short=rank_str[0]
        else:
            rank_str = str(rank)
            rank_short = str(rank)
        
    
    name = rank_str + " of " + suit

    shorthand = "{:>3s}".format(rank_short + suit[0])\

    """
    reset_flag="\033[37m"
    red_flag="\033[31m"
    Black_flag="\033[34m"
    """

    if shorthand[-1] == "H" or shorthand[-1] == "D":

        shorthand_c = str(red_flag+shorthand+reset_flag)
        print(shorthand_c)
        shorthand_color_storage(shorthand_c)

        tuple_a=(rank,suit,name,shorthand)
        deck_card_list.append(tuple_a)
        #print(tuple_a)
        return tuple_a

    else:

        shorthand_c = str(Black_flag+shorthand+reset_flag)
        shorthand_color_storage(shorthand_c)
        print(shorthand_c)
        tuple_a=(rank,suit,name,shorthand)
        #print(tuple_a)
        deck_card_list.append(tuple_a)

        return tuple_a

def shorthand_color_storage(shorthand_c):
    shorthand_c_list=[]
    shorthand_c_list.append(shorthand_c)


def shuffle():
    l=len(deck_card_list)-1
    for i in range(1,l):
        j = random.randrange(i,l)
        deck_card_list[i] = deck_card_list[j]

def draw(x):
    tup_rem=()
    #draw(3) removes the third card
    if deck_card_list:  #deck_card_list is true as long its non empty
        hand_list=[]
        remove_card_from_deck_index = x-1
        tup_rem=deck_card_list[remove_card_from_deck_index]
        hand_list.append(deck_card_list[remove_card_from_deck_index])
        deck_card_list.pop(remove_card_from_deck_index)
        return tup_rem

def deal():
    deal_hand_1=[]
    deal_hand_2=[]

    a,b = deal_hand_1,deal_hand_2

    s1=4 #The specified Number for deal_hand_1
    s2=3 #The specified Number for deal_hand_2

    count_h1 = 0
    count_h2 = 0

    for i in range(len(deck_card_list)-1):
        
        deal_hand_1.append(deck_card_list[i])
        deal_hand_2.append(deck_card_list[i+1])
        deal_hand_1 = deal_hand_1[-s1:]
        deal_hand_2 = deal_hand_2[-s2:]

    return deal_hand_1,deal_hand_2

    #len(deal_hand_1)<=specified_hand_1_length and len(deal_hand_2)<=specified_hand_2_length:
    """
    while True:
        if len(deal_hand_1)<=specified_hand_1_length:
            for items in deck_card_list:
                a.append(items)
                a,b = b,a
        elif len(deal_hand_2)<=specified_hand_2_length:
            
        print("DEAL 1",len(deal_hand_1))
        print("DEAL 2",len(deal_hand_2))
        return deal_hand_1,deal_hand_2

    """
    """
    while len(a)<=specified_hand_1_length and len(b)<=specified_hand_2_length:
        for items in deck_card_list:
            a.append(items)
            a,b = b,a
        # Adding alternatively until one of them reaches the limit
        print("DEAL 1",len(deal_hand_1))
        print("DEAL 2",len(deal_hand_2))
        #Knowing one of them is full
        if len(deal_hand_1)<=specified_hand_1_length == True:
            deal_hand_1.append(items)
        elif len(deal_hand_1)<=specified_hand_2_length == True:
            deal_hand_2.append(items)
        #return deal_hand_1,deal_hand_2

    print("DEAL 1",deal_hand_1,len(deal_hand_1))
    print("DEAL 2",deal_hand_2,len(deal_hand_2))
    """
    

        

    """
    for i in deck_card_list:
        count_h1+=1
        if len(deal_hand_1)>=specified_hand_1_length:

            for j in deck_card_list:
                    deal_hand_1.append(i)
                    deal_hand_2.append(j)
                    count_h2+=2
                    if len(deal_hand_2)>=specified_hand_2_length:
                        break
    """

    
def main():
    #Color_Off='\033[0m' Text Reset
    #Hearts and Diamonds are red and the rest is black
    
    rank_list = ["Hearts","Spades","Diamonds","Clubs"]
    for i in range(2,14):
        for j in range(len(rank_list)):
            make_card(i,rank_list[j])
            
    print("The cards on the deck are \n",deck_card_list)
    print("\n")
    #shuffle()

    print("The cards on the deck after shuffling are \n", deck_card_list)  
    print("\n")
    print(deal())
    
main()